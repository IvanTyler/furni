export enum tabsYourFurniActivityListEnum {
    overview = 'Overview',
    contacts = 'Contacts',
    events = 'Events',
}