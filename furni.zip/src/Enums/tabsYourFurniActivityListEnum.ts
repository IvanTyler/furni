export enum tabsYourFurniActivityListEnum {
    clients = 'Clients',
    partners = 'Partners',
}