export interface ITabs {
    id: number,
    name: string,
    active: boolean,
}