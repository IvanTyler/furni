export interface IFilterContacts {
    id: number,
    name: string,
    active: boolean,
}