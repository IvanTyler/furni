export interface IDetailContacts {
    direct_sales: number;
    via_partners: number;
    via_subpartners: number;
}

export interface IDetailEvents {
    Sale_type: string;
    Deal_amount: number;
    Your_commission: number;
    Reference_code: string,
}