import style from './FilterContacts.module.scss'
import { useState } from 'react'
import { IFilterContacts } from '../../Interfaces/FilterContacts'
import { List } from '../List/List'
import { FilterContactsItem } from '../FilterContactsItem/FilterContactsItem'
import cx from 'classnames'

interface IFilterContactsProps {
    isFilterContactsActive: boolean
    setIsFilterContactsActive: (item: boolean) => void
    filterClients: () => void
    setAllContacts: () => void
    filterPartners: () => void
    filterSubPartners: () => void
    setTitleContacts: (item: string) => void
}

export const FilterContacts: React.FC<IFilterContactsProps> = (
    {
        isFilterContactsActive,
        setIsFilterContactsActive,
        setAllContacts,
        filterClients,
        filterPartners,
        filterSubPartners,
        setTitleContacts,
    }
) => {

    const filterContactsItems: IFilterContacts[] = [
        {
            id: 1,
            name: 'All contacts',
            active: true,
        },
        {
            id: 2,
            name: 'Clients',
            active: false,
        },
        {
            id: 3,
            name: 'Partners',
            active: false,
        },
        {
            id: 4,
            name: 'Subpartners',
            active: false,
        },
    ]

    const [filterContactsItem, setFilterContactsItem] = useState<IFilterContacts[]>(filterContactsItems)


    const itemFilterContactsEditHandler = (id: number, name: string) => {
        setIsFilterContactsActive(false)

        const currentname = filterContactsItem.find((el: IFilterContacts) => el.name === name)
        if (currentname?.name === 'Clients') {
            filterClients()
            setTitleContacts('Clients')
        }
        if (currentname?.name === 'All contacts') {
            setAllContacts()
            setTitleContacts('All contacts')
        }
        if (currentname?.name === 'Partners') {
            filterPartners()
            setTitleContacts('Partners')
        }
        if (currentname?.name === 'Subpartners') {
            filterSubPartners()
            setTitleContacts('Subpartners')
        }

        setFilterContactsItem((prev: any) => {
            return prev.map((el: any) => {
                if (el.id === id) {
                    return {
                        ...el,
                        active: true,
                    }
                } else if (el.id !== id) {
                    return {
                        ...el,
                        active: false,
                    }
                }
                return el
            })
        })
    }

    return (
        <ul className={
            isFilterContactsActive ?
                style.FilterContactsList :
                cx(style.FilterContactsList, style.hide)
        }>
            <List
                items={filterContactsItem}
                renderItem={(item: IFilterContacts, index: number) => <FilterContactsItem
                    itemFilterContactsEditHandler={itemFilterContactsEditHandler}
                    item={item}
                    key={index.toString()}
                />}
            />
        </ul>
    )
}